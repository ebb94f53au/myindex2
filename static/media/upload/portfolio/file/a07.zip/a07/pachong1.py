import urllib.request
import re
import os
import time
#
#2018-4-5
#智联招聘大数据爬取数据
#
#

jobType=['岗位名称','职位类别','学历','工作年限','公司','公司性质','公司规模','工作地点','薪水']

#得到初始网页内容
def getHtml(url):
    request=urllib.request.urlopen(url)
    html=request.read().decode('utf-8','ignore')
    return html
    

#找寻网站内容网址,返回网址列表
def findUrlsByUrl(url):
    urlList=[]
    html=getHtml(url)
    p1=r'<a style="font-weight: bold" par=".*?" href="(.*?)" target="_blank">.*?</a>'
    l=re.findall(p1,html)
    for i in l:
        if not('xiaoyuan.zhaopin.com'in i):
            urlList.append(i)
    return urlList


#找寻网址页数,和下面深度挖觉页数配合使用
def findUrlNum(url):
    html=getHtml(url)
    a1=html.find('上一页')
    a2=html.find('下一页')
    urlNum=html[a1:a2]
    a3=urlNum.find('class="current"')
    urlNum=urlNum[a3:]
    p=r'</li><li><a href="(.*?)">\d*</a>'
    urlListByNum=re.findall(p,urlNum)
    return urlListByNum

#深度挖掘页数 参数 初始网址，页数
def findMoreUrlNum(url,page):
    urlListByNum=findUrlNum(url)
    while len(urlListByNum)<page:
        urls=findUrlNum(urlListByNum[-1])
        for i in urls:
            if not(i in urlListByNum):
                urlListByNum.append(i)

            print(len(urlListByNum))    
            
    urlListByNum.append(url)
    
    return urlListByNum

#根据网址得到职位数据内容  参数为网址列表 以及当前时间（为创建文件名）
def getContent(urllist,time):
    Jname=r'<title>【(.*?)_.*?】 - 智联招聘</title>'
    Jtype=r'<li><span>职位类别：</span><strong><a.*?>(.*?)</a></strong></li>'
    Jedu=r'<li><span>最低学历：</span><strong>(.*?)</strong></li>'
    Jtime=r'<li><span>工作经验：</span><strong>(.*?)</strong></li>'
    Jcompany=r'var Str_CompName = "(.*?)";'
    Jctype=r'<li><span>公司性质：</span><strong>(.*?)</strong></li>'
    Jsize=r'li><span>公司规模：</span><strong>(.*?)</strong></li>'
    Jaddr=r'<li><span>工作地点：</span><strong><a target=".*?" href=".*?">(.*?)</a>'
    Jmoney=r'<li><span>职位月薪：</span><strong>(.*?)&nbsp;<a'
    Jlist=[Jname,Jtype,Jedu,Jtime,Jcompany,Jctype,Jsize,Jaddr,Jmoney]

    for i in urllist:
        print(i)
        content=[]
        html=getHtml(i)
        for x in range(len(Jlist)):
            
            content.append(re.findall(Jlist[x],html))
            #print(not content[x])
            if not content[x]:
                content[x].append(' ')
        print(content)
        with open(now+'.csv','a',encoding='utf-8') as f:
            if os.path.getsize(now+'.csv')==0:
                f.write('岗位名称,职位类别,学历,工作年限,公司,公司性质,公司规模,工作地点,薪水\n')
            for n in content:
                f.write(n[0]+',')

            f.write('\n')
        

if __name__=="__main__":
    now=time.strftime("%Y-%m-%d", time.localtime()) #当前时间
    #url1='http://sou.zhaopin.com/jobs/searchresult.ashx?jl=%e6%ad%a6%e6%b1%89%2b%e5%8c%97%e4%ba%ac%2b%e4%b8%8a%e6%b5%b7%2b%e5%b9%bf%e5%b7%9e%2b%e6%b7%b1%e5%9c%b3&kw=%e5%a4%a7%e6%95%b0%e6%8d%ae&isadv=0&sg=2ff483cba3524155b902773ad9c7d6d4&p=1'
    url1='https://sou.zhaopin.com/jobs/searchresult.ashx?bj=160000&jl=%E5%8D%97%E4%BA%AC%2B%E5%A4%A9%E6%B4%A5%2B%E8%A5%BF%E5%AE%89%2B%E6%88%90%E9%83%BD%2B%E5%A4%A7%E8%BF%9E&p=1&isadv=0'
    page=88
    urlListByNum=findMoreUrlNum(url1,page)
    for i in urlListByNum:
        urllist=findUrlsByUrl(i)
        '''
        with open('a.txt','a') as f:
            for x in urllist:
                f.write(x+'\n')
        '''  
        getContent(urllist,now)
