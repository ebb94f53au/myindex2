import pandas as pd
import matplotlib.pyplot as plt
import re
# from  __future__ import print_function
# from apriori import *
from  sklearn.manifold import TSNE
datafile= 'later.csv' #航空原始数据,第一行为属性标签
cleanedfile = 'D:/test/fenxi.csv' #数据清洗后保存的文件
plt.rcParams['font.sans-serif']=['simhei']       #画图可中文
plt.rcParams['font.family']='sans-serif'
plt.rcParams['axes.unicode_minus']=False
#####学历饼图
f = plt.figure()
plt.title('大数据学历需求情况')#设置标题
data = pd.read_csv(datafile,encoding='gbk',delimiter=',')
cou = data['学历'].count()
labels=['大专','中专','本科','不限','硕士','博士']
a1=data['学历'].value_counts()['大专']/cou
a2=data['学历'].value_counts()['中专']/cou
a3=data['学历'].value_counts()['本科']/cou
a4=data['学历'].value_counts()['不限']/cou
a5=data['学历'].value_counts()['硕士']/cou
a6=data['学历'].value_counts()['博士']/cou
sizes = [a1,a2,a3,a4,a5,a6]
colors='lightgreen','gold','lightskyblue','lightcoral','blue','yellow'
explode=0,0,0,0,0,0
plt.pie(sizes,explode=explode,labels=labels,
        colors=colors,autopct='%1.1f%%',startangle=50)
plt.axis('equal')
plt.savefig("分析图片/学历饼图.png")
#######岗位类别饼图
f = plt.figure()
plt.title('大数据领域细分技术需求分布图')#设置标题
jtlist=[u'高级软件工程师',u'软件工程师',u'数据库开发工程师',u'Java开发工程师',u'系统架构设计师',u'软件研发工程师',u'算法工程师',u'PHP开发工程师',u'WEB前端开发',u'互联网软件工程师']
t1=data['职位类别'].value_counts()['高级软件工程师']/cou
t2=data['职位类别'].value_counts()['软件工程师']/cou
t3=data['职位类别'].value_counts()['数据库开发工程师']/cou
t4=data['职位类别'].value_counts()['Java开发工程师']/cou
t5=data['职位类别'].value_counts()['系统架构设计师']/cou
t6=data['职位类别'].value_counts()['软件研发工程师']/cou
t7=data['职位类别'].value_counts()['算法工程师']/cou
t8=data['职位类别'].value_counts()['PHP开发工程师']/cou
t9=data['职位类别'].value_counts()['WEB前端开发']/cou
t10=data['职位类别'].value_counts()['互联网软件工程师']/cou

sizes = [t1,t2,t3,t4,t5,t6,t7,t8,t9,t10]
colors='lightgreen','gold','lightskyblue','lightcoral','blue','yellow','green','purple','gray','pink'
explode=0,0,0,0,0,0,0,0,0,0
plt.pie(sizes,explode=explode,labels=jtlist,
        colors=colors,autopct='%1.1f%%',startangle=50)
plt.axis('equal')
# plt.show()
plt.savefig("分析图片/职位饼图.png")
########绘制城市折线图
#X轴，Y轴数据
f = plt.figure()
a=data.groupby('工作地点').size().sort_values(ascending=False)
a.plot()
plt.title("大数据城市人才需求分布") #图标题
plt.savefig("分析图片/城市折线.png")
plt.show()  #显示图
