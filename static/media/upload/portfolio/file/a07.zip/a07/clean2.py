import pandas as pd
import numpy as np
#
#数据挖掘与清理
#
#
#
#

df=pd.read_csv('2018-06-15.csv',delimiter=',',encoding='ANSI',names=[u'岗位名称',u'职位类别',u'学历',u'工作年限',u'公司',u'公司性质',u'公司规模',u'工作地点',u'薪水'])

df=df[1:]#去掉表头
df=df.drop_duplicates().reset_index().drop('index',axis=1)#去重清理

index1=df[u'职位类别']==u'高级软件工程师'
index2=df[u'职位类别']==u'软件工程师'
index3=df[u'职位类别']==u'数据库开发工程师'
index4=df[u'职位类别']==u'Java开发工程师'
index5=df[u'职位类别']==u'系统架构设计师'
index6=df[u'职位类别']==u'软件研发工程师'
index7=df[u'职位类别']==u'算法工程师'
index8=df[u'职位类别']==u'PHP开发工程师'
index9=df[u'职位类别']==u'WEB前端开发'
index10=df[u'职位类别']==u'互联网软件工程师'

df=df[index3|index4|index5|index7|index8|index9|index10]

df1=df[df[u'薪水']==u'面议']#取出工资为面议
df1.to_csv('面议.csv',index=False, sep=',',encoding='ANSI')

df[u'公司规模']=df[u'公司规模'].str.strip(u'人')#清理公司规模
df[u'公司规模']=(pd.to_numeric(df[u'公司规模'].str.split(u'-',1).str.get(1),errors='coerce')+pd.to_numeric(df[u'公司规模'].str.split(u'-',1).str.get(0),errors='coerce'))//2
df=df[df[u'公司规模'].notnull()]
#区间分为0-100 100-300 300-1000 1000-10000

df[u'公司规模区间']=None
dex1=df[u'公司规模']<100
dex2=df[u'公司规模']>=100
dex3=df[u'公司规模']<300
dex4=df[u'公司规模']>=300
dex5=df[u'公司规模']<1000
dex6=df[u'公司规模']>=1000
dex7=df[u'公司规模']<10000
df.loc[dex1,u'公司规模区间']='0-100人'
df.loc[dex2&dex3,u'公司规模区间']='100-300人'
df.loc[dex4&dex5,u'公司规模区间']='300-1000人'
df.loc[dex6&dex7,u'公司规模区间']='1000-10000人'


df=df[df[u'薪水']!=u'面议']#清理薪水，并添加薪水平均数，行业薪水区间，并剔除空值
jtlist=[u'高级软件工程师',u'软件工程师',u'数据库开发工程师',u'Java开发工程师',u'系统架构设计师',u'软件研发工程师',u'算法工程师',u'PHP开发工程师',u'WEB前端开发',u'互联网软件工程师']
df[u'薪水']=df[u'薪水'].str.strip(u'元/月')#清理薪水
df[u'薪水平均数']=(pd.to_numeric(df[u'薪水'].str.split(u'-',1).str.get(1),errors='coerce')+pd.to_numeric(df[u'薪水'].str.split(u'-',1).str.get(0),errors='coerce'))/2
df[u'薪水最大值']=pd.to_numeric(df[u'薪水'].str.split(u'-',1).str.get(1),errors='coerce')
df[u'薪水最小值']=pd.to_numeric(df[u'薪水'].str.split(u'-',1).str.get(0),errors='coerce')
df[u'行业薪水区间']=None
for i in jtlist:
    df.loc[df[u'职位类别']==i,u'行业薪水区间']=str(df.loc[df[u'职位类别']==i,u'薪水最小值'].min())+'-'+str(df.loc[df[u'职位类别']==i,u'薪水最大值'].max())
    
df=df[df[u'薪水平均数'].notnull()]




df[u'工作年限平均数']=None
df[u'工作年限平均数']=df[u'工作年限'].str.split(u'年').str[0]#清理工作年限
dex8=df[u'工作年限平均数']=='无经验'
dex9=df[u'工作年限平均数']=='不限'
df.loc[dex8|dex9,u'工作年限平均数']='0-0'
df[u'工作年限平均数']=(pd.to_numeric(df[u'工作年限平均数'].str.split(u'-',1).str.get(1),errors='coerce')+pd.to_numeric(df[u'工作年限平均数'].str.split(u'-',1).str.get(0),errors='coerce'))/2
df=df.drop([u'薪水最大值',u'薪水最小值'],axis=1)
df.loc[df['学历']=='博士','学历']='研究生（博士）'
df.loc[df['学历']=='硕士','学历']='研究生（硕士）'
df.loc[df['工作年限']=='无经验','工作年限']='不限'



df.to_csv('later_2.csv',index=False, sep=',',encoding='ANSI')




