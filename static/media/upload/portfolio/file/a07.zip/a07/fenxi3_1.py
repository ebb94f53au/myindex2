import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

plt.rcParams['font.sans-serif']=['simhei']       #画图可中文
plt.rcParams['font.family']='sans-serif'
plt.rcParams['axes.unicode_minus']=False
df=pd.read_csv('later.csv',delimiter=',',encoding='ANSI',names=[u'岗位名称',u'职位类别',u'学历',u'工作年限',u'公司',u'公司性质',u'公司规模',u'工作地点',u'薪水','公司规模区间',u'薪水平均数',u'行业薪水区间',u'工作年限平均数'])


df=df[1:].reset_index()
df[u'薪水平均数']=pd.to_numeric(df[u'薪水平均数'],errors='coerce')
df[u'公司规模']=pd.to_numeric(df[u'公司规模'],errors='coerce')
df[u'工作年限平均数']=pd.to_numeric(df[u'工作年限平均数'],errors='coerce')

#########################################################################################
#岗位工资的影响因素
Jlist=[u'职位类别',u'学历',u'工作年限',u'公司性质',u'工作地点',u'公司规模区间']
for i in range(len(Jlist)):
    df1=df.groupby(Jlist[i]).mean()
    f1 = plt.figure()
    plt.xticks(rotation=45,fontsize=8)
    df1[u'薪水平均数'].plot(kind='bar',title=Jlist[i]+'与平均月薪影响因素')
    plt.savefig('分析图片/'+str(i)+'.png')
########################职位类别与工作年限影响因素
f2 = plt.figure()
plt.xticks(fontsize=8)
df2=df.groupby(u'职位类别').mean()
#print(df2[u'工作年限平均数'])
df2[u'工作年限平均数'].plot(kind='bar',title='职位类别与工作年限影响因素')
plt.savefig('分析图片/7.png')

###############################################################################################
J2=[u'公司规模区间',u'工作年限',u'行业薪水区间']
title=['大数据需求企业规模情况','大数据经验需求情况','大数据领域薪酬变化趋势']
for i in range(len(J2)):
    f3 = plt.figure()
    plt.xticks(fontsize=8)
    df3=df.groupby(J2[i]).size()
    df3.plot(kind='bar',title=title[i])
    plt.savefig('分析图片/'+J2[i]+'.png')
#plt.show()



