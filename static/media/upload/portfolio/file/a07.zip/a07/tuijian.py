import pandas as pd
from sklearn import preprocessing
input='later.csv'
data=pd.read_csv(input,sep=',',encoding='gbk')
data=data.drop('薪水平均数',axis=1)
tlist=['职位类别','学历', '工作年限','工作地点']
ans=data.loc[:,tlist]
# 标签标准化
le=preprocessing.LabelEncoder()
c_list=[]
for i in tlist:
    le.fit_transform(data[i])
    ans[i]=le.transform(data[i])
    c_list.append(le.classes_)
from sklearn.metrics.pairwise import cosine_similarity
user_similarity = cosine_similarity([[5,3,2,1]],ans)
ans['sim']=user_similarity[0]
ans=ans.sort_values(by='sim',ascending=False).head(5)
res=list(ans.index)
print(data.iloc[res,:])


