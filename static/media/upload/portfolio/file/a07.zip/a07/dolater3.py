import pandas as pd
input1='later_1.csv'
input2='later_2.csv'
data1=pd.read_csv(input1,sep=',',encoding='ansi')
data2=pd.read_csv(input2,sep=',',encoding='ansi')
print(len(data1))
print(len(data2))
data=pd.concat([data1,data2],axis=0)
data=data.drop_duplicates().reset_index().drop('index',axis=1)
print(len(data))
data.to_csv('later3.csv',sep=',',index=None,encoding='utf-8')
