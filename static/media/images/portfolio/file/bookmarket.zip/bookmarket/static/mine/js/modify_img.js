function checksubmit(){
        if(accunterr.style.display=="none"&&
        passwderr.style.display=="none"&&
        checkerr.style.display=="none"&&
        passerr.style.display=="none"){

            return true
        }else{

        return false
        }
}